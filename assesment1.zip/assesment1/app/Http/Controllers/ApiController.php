<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\User;
use App\Checkout;
use App\Address;
use App\Cart;


class ApiController extends Controller
{
    public function create_product(Request $request){

        $create_product=new Product();
        $create_product->name=$request->name;
        $create_product->price=$request->price;
        $create_product->quantity=$request->quantity;
        $create_product->save();
        return "Item Created";

    }
    public function create_user(Request $request){

        $create_user=new user();
        $create_user->name=$request->first_name.$request->last_name;
        $create_user->first_name=$request->first_name;
        $create_user->last_name=$request->last_name;
        $create_user->email=$request->email;
        $create_user->password=bcrypt($request->password);
        $create_user->address1=$request->address1;
        $create_user->address2=$request->address2;
        $create_user->state=$request->state;
        $create_user->city=$request->city;
        $create_user->zip=$request->zip;
        $create_user->save();
        return "user Created";

    }
    public function customer_details(Request $request){

        $customer_details=User::where('id',$request->id)->first();
        return response()->json(['customer_details' => $customer_details]);

    }
    public function customer_address(Request $request){

        $customer_address=User::select('address1','address2','state','zip')->where('id',$request->id)->first();
        return response()->json(['customer_address' => $customer_address]);

    }
    public function item_in_cart(Request $request){

        $item_in_cart=Cart::where('user_id',$request->id)->get();
        return response()->json(['item_in_cart' => $item_in_cart]);

    }
}
