<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Product;
use App\Cart;
use App\Checkout;
use App\User;



class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth')->except(['product','checkout','product_details','index']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  
         $products=Product::all();
        return view('welcome',compact('products'));
    }
    public function product()
    {
        $product=Product::all();
        return view('products',compact('product'));
    }
    
    public function checkout()
    {
        $checkout=Checkout::where('user_id',Auth::user()->id)->get();
        $user=User::where('id',Auth::user()->id)->first();
        return view('checkout',compact('checkout','user'));
    }
    public function product_details($id)
    {
        $product_details=Product::find($id);
        $product=Product::all();

        return view('product-details',compact('product_details','product'));
    }
    public function addcart(Request $request)
    {
       $addcard=new Cart();
       $addcard->product_id=$request->product_id;
       $addcard->user_id=$request->user_id;
       $addcard->price=$request->price;
       $addcard->quantity=$request->quantity;
       $addcard->product_name=$request->product_name;
       $addcard->total=$request->price*$request->quantity;



       $addcard->save();
       return redirect('/cart');


    }
    public function cart(Request $request)
    {
        $cart=Cart::where('user_id',Auth::user()->id)->get();
        return view('cart',compact('cart'));
    }

    public function addcheckout(Request $request)
    {

       
      
       foreach($request->product_name as $key=>$product)
       {
            $addcard=new Checkout();
            $addcard->product_name=$product;
            $addcard->quantity=$request->quantity[$key];
            $addcard->product_id=$request->product_id[$key];
            $addcard->user_id=$request->user_id[$key];
            $addcard->price=$request->price[$key];
            $addcard->total=$request->price[$key]*$request->quantity[$key];
            $addcard->tax='7';
            $addcard->save();
       }
      
       
  

       return redirect('/checkout');


    }

    public function delete($id)
    {
        $product_details=Cart::find($id)->delete();
        

       return redirect('/cart');
        
    }
}
