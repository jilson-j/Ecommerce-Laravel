@extends('layouts.app')

@section('content')
<!-- Page Content -->
<div class="page-heading about-heading header-text" style="background-image: url(/images/heading-6-1920x500.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>Lorem ipsum dolor sit amet</h4>
              <h2>Product Details</h2>
            </div>
          </div>
        </div>
      </div>
    </div>

   
    <div class="products">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-xs-12">
            <div>
              <img src="/images/product.jpg" alt="" class="img-fluid wc-image">
            </div>
            <br>
            <div class="row">
              <div class="col-sm-4 col-xs-6">
                <div>
                  <img src="/images/product.jpg" alt="" class="img-fluid">
                </div>
                <br>
              </div>
              <div class="col-sm-4 col-xs-6">
                <div>
                  <img src="/images/product.jpg" alt="" class="img-fluid">
                </div>
                <br>
              </div>
              <div class="col-sm-4 col-xs-6">
                <div>
                  <img src="/images/product.jpg" alt="" class="img-fluid">
                </div>
                <br>
              </div>
            </div>
          </div>

          <div class="col-md-8 col-xs-12">
            <form action="/addcart" method="post" class="form">
            @csrf
              <h2>{{$product_details->name}}</h2>

              <br>

              <p class="lead">
                <small><del> $999.00</del></small><strong class="text-primary">${{$product_details->price}}</strong>
              </p>

              <br>

              <p class="lead">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi ratione molestias maxime odio. Provident ratione vero, corrupti, optio laborum aut!
              </p>

              <br> 

              <div class="row">
                
                <div class="col-sm-8">
                  <label class="control-label">Quantity</label>

                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input type="text" class="form-control" value="1"  name="quantity">
                      </div>
                    </div>
                   
                    <input type="hidden" class="form-control" name="price" value="{{$product_details->price}}">
                    <input type="hidden" class="form-control" name="product_id" value="{{$product_details->id}}">
                    <input type="hidden" class="form-control" name="product_name" value="{{$product_details->name}}">

                    
                     
                    @if(Auth::user())
                    <input type="hidden" class="form-control" name="user_id" value="{{Auth::user()->id}}">
                    @else
                    @endif
                   
                    <div class="col-sm-6">
                      <button type="submit" class="btn btn-primary btn-block">Add to Cart</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="latest-products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Similar Products</h2>
              <a href="products.html">view more <i class="fa fa-angle-right"></i></a>
            </div>
          </div>
          @foreach($product as $pro)
          <div class="col-md-4">
            <div class="product-item">
              <a href="product-details.html"><img src="/images/product.jpg" alt=""></a>
              <div class="down-content">
                <a href="product-details.html"><h4>{{$pro->name}}</h4></a>
                <h6><small><del>$999.00 </del></small> ${{$pro->price}}</h6>
              </div>
            </div>
          </div>
        @endforeach
          

          
        </div>
      </div>
    </div>

   

    



@endsection
